section class=menu-section
        div class=container
            div class=row
                div class=col-md-12
                    div class=navbar-collapse collapse 
                        ul id=menu-top class=nav navbar-nav navbar-right
                             lia href=pincode-verification.phpEnroll for Course ali
                             lia href=enroll-history.phpEnroll History  ali
                              lia href=my-profile.phpMy Profileali
                               lia href=change-password.phpChange Passwordali
                            lia href=logout.phpLogoutali

                        ul
                    div
                div

            div
        div
   section class=menu-section
        div class=container
            div class=row
                div class=col-md-12
                    div class=navbar-collapse collapse 
                        ul id=menu-top class=nav navbar-nav navbar-right
                             lia href=pincode-verification.phpEnroll for Course ali
                             lia href=enroll-history.phpEnroll History  ali
                              lia href=my-profile.phpMy Profileali
                               lia href=change-password.phpChange Passwordali
                            lia href=logout.phpLogoutali

                        ul
                    div
                div

            div
        div
   